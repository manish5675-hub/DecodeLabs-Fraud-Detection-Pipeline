# Week 2 - Fraud Detection Pipeline

## Objective
Build a fraud detection model on an imbalanced dataset using SMOTE and evaluate using Precision, Recall and ROC-AUC.

## Project Workflow
1. Data loading and preprocessing
2. Exploratory Data Analysis
3. Handling class imbalance using SMOTE
4. Model training using:
   - Logistic Regression
   - Random Forest
5. Model evaluation using:
   - Precision
   - Recall
   - F1 Score
   - ROC-AUC

## Dataset Columns
OrderID, Date, CustomerID, Product, Quantity, UnitPrice, ShippingAddress, PaymentMethod, OrderStatus, TrackingNumber, ItemsInCart, CouponCode, ReferralSource, TotalPrice

## Technologies
Python, Pandas, Scikit-Learn, Imbalanced-Learn, Matplotlib
